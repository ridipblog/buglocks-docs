import Request from "./Request.js?t=Date.now()";

class Execute extends Request {
    constructor() {
        super();
    }

    // *** Render Page ***
    renderPage = async (currentState) => {
        let routePage = currentState.val();
        let route=window?.buglocks?.route ?? null;
        if ((route !== null) &&(route!=="")) {
            routePage = route;
        }
this.handleResponse = async (response) => {
            $('.page-content').html(response);
        }
        await this._handleGet(`resources/views/pages/${routePage}.php`, {}, true);
        let currentPath = window.location.pathname;
console.log("Current path:", currentPath);

const pathParts = currentPath.split('/').filter(Boolean);
let lastRoute = pathParts.pop();
currentPath = '/' + pathParts.join('/');

if (!currentPath.endsWith(`/${routePage}`)) {
    const basePath = (lastRoute === '') 
        ? `${currentPath}/${lastRoute}`
        : currentPath;

        console.log("set 1",basePath);

    // Ensure single slashes and encode properly
    const newPath = `${basePath}/${routePage}`.replace(/\/+/g, '/');
    console.log("New Path:", newPath);

    // Push only if it's still on the same origin
    try {
        history.pushState(null, '', newPath);
    } catch (e) {
        console.error("PushState failed:", e);
    }
}


        $('.nav-btn').removeClass('active');
        $(`#${routePage}`).addClass('active');
        window.buglocks.route = null;

    }
}

export default Execute;