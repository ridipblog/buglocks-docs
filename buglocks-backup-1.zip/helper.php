<?php
function asstes(string $location)
{
    require_once __DIR__ . "/css/" . $location;
}
