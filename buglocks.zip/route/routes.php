<?php

// *** All Routes Assigned Here ***
$routes=[
    '', // If run on production server
    'buglocks', // If run on development server
    'introduction',
    'installation',
    'rolePermission',
    'assignLocks',
    'authentication',
    'pages',
    '404',
];