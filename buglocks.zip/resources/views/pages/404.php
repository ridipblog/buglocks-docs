<div class="not-found-container">
  <div class="not-found-icon">
    <i class="bi bi-exclamation-triangle-fill"></i>
  </div>
  <h1 class="display-4">404</h1>
  <p class="lead">Oops! The route you’re looking for doesn’t exist.</p>
  <a href="/php_projects/documentations/buglocks/introduction" class="btn btn-danger not-found-btn">Go Home</a>
</div>