<div class="mb-4">
    <h5><?= $cardHead ?? '' ?></h5>
    <p><?= $cardText ?? '' ?></p>
    <div class="example-box">
        <p>📌 Code Example:</p>
        <div class="code">
            <pre><code>
<?= $code ?? '' ?>
</pre></code>
        </div>
    </div>
</div>