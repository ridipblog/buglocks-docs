<div class="card shadow-sm mb-4">
    <div class="card-body">
        <h5 class="card-title text-success">📌 Code Example:</h5>
        <div class="code-block">
            <pre><code>
<?= $code ?? '' ?>
            </code></pre>
        </div>
    </div>
</div>